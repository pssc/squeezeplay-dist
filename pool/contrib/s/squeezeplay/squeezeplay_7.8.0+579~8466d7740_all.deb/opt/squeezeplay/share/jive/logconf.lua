return {
  appender={ stdout="warn", syslog="debug" },
  category={
    ["squeezeplay"]="INFO", 
    ["squeezeplay.ui"]="INFO",
    ["squeezeplay.ui.draw"]="INFO"
  }
}
